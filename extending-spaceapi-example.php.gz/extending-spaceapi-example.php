<?php
/*
Plugin Name: Add something to space api
Description: Example
Version: 0.1
License: WTFPL
Author: Florian Holzhauer
Author URI: http://fholzhauer.de/
*/

function addSomethingToSpaceApiJsonOutput($data)
{
    $data['ext_hello_world'] = 'Wheeeee';
    return $data;
}

add_filter('spaceapi_data_result', 'addSomethingToSpaceApiJsonOutput');
